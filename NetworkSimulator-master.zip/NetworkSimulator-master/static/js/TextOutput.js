function display(msg){
    statusPanel.innerHTML += msg;
    statusPanel.scrollTop = statusPanel.scrollHeight;
}
